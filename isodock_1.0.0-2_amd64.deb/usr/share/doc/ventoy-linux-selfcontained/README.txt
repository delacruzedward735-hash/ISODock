Ventoy Linux Native GUI build 1.1.17-6

This revision removes the custom Python/PyGObject GUI introduced in build -5.
It launches Ventoy's native GTK3 Ventoy2Disk interface directly through
VentoyGUI.x86_64 --gtk3.

The Linux automount workaround is retained in tool/ventoy_lib.sh: target USB
partitions are unmounted by block-device source, including mountpoints whose
labels contain spaces (represented as \\040 in /proc/mounts), with an automount
race retry after udev settles.

Commands:
  ventoy-linux
  ventoy-linux --doctor
  ventoy-linux --list
  ventoy-linux --log
